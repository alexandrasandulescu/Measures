package org.measure.impl;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import org.measure.smm.measure.api.IMeasurement;
import org.measure.smm.measure.defaultimpl.measures.DirectMeasure;
import org.sonar.wsclient.Sonar;
import org.sonar.wsclient.services.Measure;
import org.sonar.wsclient.services.Resource;
import org.sonar.wsclient.services.ResourceQuery;

import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.lang.StringBuilder;

import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.Gson;

import java.net.URL;
import java.net.URLConnection;

class Executable {
  String state;
  String name;
  String platform;
  String execution;
  Object features;
  String sha256;
  String size;
  Object fuzzer;
  Object corpus;
  String id;
}

@objid ("2d633e05-f3cd-4d90-97c3-d4f404a1b44e")
public class DirectMeasureImpl extends DirectMeasure {

    @objid ("6adfa71e-eafc-4fa9-9cde-a658277d0fe3")
    @Override
    public List<IMeasurement> getMeasurement() throws Exception {
        String serverURL = getProperty("ServerURL");
        String jwtToken = getProperty("JWTToken");

        try {

            // get all executables
            URLConnection getExecsConn = new URL(serverURL + "/api/executables").openConnection();
            getExecsConn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            InputStream execsResponse = getExecsConn.getInputStream();
            InputStreamReader isr = new InputStreamReader(execsResponse, "UTF-8");

            Gson gson = new Gson();
            Executable[] executables = gson.fromJson(isr, Executable[].class);

            for (int i = 0; i < executables.length; ++i) {
              System.out.println(executables[i].id);
            }

            //URLConnection connection = new URL(serverURL + "?" + query).openConnection();
            //Sonar sonar = Sonar.create(serverURL, login, password);
            //Resource struts = sonar.find(ResourceQuery.createForMetrics(projectKey, "lines"));
            //Measure m = struts.getMeasure("lines");
        
            //List<IMeasurement> result = new ArrayList<IMeasurement>();
            //DoubleMeasurement data = new DoubleMeasurement();
            //data.setValue(m.getValue());
            //result.add(data);
        
            //return result;
            return new ArrayList<IMeasurement>();
        } catch (Exception e) {
            throw new Exception("Error during Measure Execution : " + e.getMessage(), e);
        }
    }

}

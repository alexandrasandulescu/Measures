package org.measure.test;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import org.measure.smm.measure.api.IMeasurement;

@objid ("ff774025-c7ee-4909-b2bf-2743405c8350")
public class Test {
    @objid ("d6ec53fb-1a27-408c-9fc5-5f8554b379b8")
    @org.junit.Test
    public void testMeasure() {
        org.measure.impl.DirectMeasureImpl measure = new org.measure.impl.DirectMeasureImpl();
        try {
            
            
           
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
